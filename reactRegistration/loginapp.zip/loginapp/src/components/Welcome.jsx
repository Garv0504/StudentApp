import React from 'react'
import Home from './Home'

const Welcome = () => {
  return (
    <>
        <h1>Welcome to our Website</h1>
        <Home/>
    </>
  )
}

export default Welcome