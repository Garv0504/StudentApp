import React from 'react'
import StudentAdmin from './StudentAdmin'

const Dashboard = () => {
  return (
    <StudentAdmin/>
  )
}

export default Dashboard